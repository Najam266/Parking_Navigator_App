﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APP
{
    public partial class @new : Form
    {
        public @new()
        {
            InitializeComponent();
        }

        private void new_Load(object sender, EventArgs e)
        {

        }
    }
}
